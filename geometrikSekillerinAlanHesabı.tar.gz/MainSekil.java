package geometrikSekillerinAlanHesabı;

import java.util.Scanner;

public class MainSekil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Geometrik Şekillerin Alan Hesaplaması Uygulamasına Hoşgeldiniz...");
		
		String islemler = "1. islem : ucgenin alanı\n"
						+ "2. işlem : karenin alanı\n"
						+ "3. işlem : dairenin alanı\n"
						+ "4. işlem : çıkış";
		
		boolean cikis = true;
		
		while(cikis) {
			
			System.out.println(islemler);
			
			System.out.println("Lütfen hangi işlemi yapmak istiyorsanız o işlemin numarasını giriniz ");
			int islem = scanner.nextInt();
			
			Sekil sekil = null;
			
			switch(islem) {
			
				case 1:
					System.out.println("üçgenin 3 kenarının uzunluklarını sırasıyla giriniz : ");
					int a= scanner.nextInt();
					int b = scanner.nextInt();
					int c = scanner.nextInt();
					
					sekil = new Ucgen("üçgen1",a,b,c);
					sekil.alanHesapla();
					break;
					
				case 2:
					System.out.println("lütfen karenin kenar uzunluğunu giriniz :");
					int kenar = scanner.nextInt();
					
					sekil = new Kare("kare1", kenar);
					sekil.alanHesapla();
					break;
					
				case 3 :
					System.out.println("lütfen dairenin yarıçap uzunluğunu giriniz : ");
					int yaricap = scanner.nextInt();
					
					sekil = new Daire("daire1",yaricap);
					sekil.alanHesapla();
					break;
					
				case 4:
					System.out.println("programdan çıkış yapılıyor ...");
					cikis = false;
					break;
					
			}
		}

	}

}
