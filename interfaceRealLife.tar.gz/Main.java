package interfaceRealLife;

public class Main {
	
	public static void main(String[] args) {
		
		User user = new User("1","talih",19);
		UserCheckManager userCheckManager = new UserCheckManager(new NameUserCheck());
		userCheckManager.kayit(user);
	}

}
