package interfaceRealLife;

public class NameUserCheck implements IUserCheck{

	@Override
	public boolean kayit(User user) {
		
		if(user.getName().startsWith("s"))
			return true;
		else
			return false;
	}
	
	


}
