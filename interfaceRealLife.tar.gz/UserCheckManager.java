package interfaceRealLife;

public class UserCheckManager {
	
	private IUserCheck userCheck;
	




	public UserCheckManager(IUserCheck userCheck) {
		
		this.userCheck = userCheck;
	}





	public void kayit(User user) {
		
		
		
		if(userCheck.kayit(user) == false){
			System.out.println(user.getName() + " kaydolamadı...");
		}
		else
			System.out.println(user.getName()  + " kaydoldu");

		
	}
	
	

}
