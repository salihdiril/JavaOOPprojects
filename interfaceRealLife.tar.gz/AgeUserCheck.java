package interfaceRealLife;

public class AgeUserCheck implements IUserCheck{

	@Override
	public boolean kayit(User user) {
		
		if(user.getAge() < 18)
			return false;
		else
			return true;
	}
	
	

}
