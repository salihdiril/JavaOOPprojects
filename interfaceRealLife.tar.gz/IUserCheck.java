package interfaceRealLife;

public interface IUserCheck {
	
	public boolean kayit(User user);

}
