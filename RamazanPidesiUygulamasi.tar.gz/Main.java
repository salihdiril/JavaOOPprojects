package ramazanPidesiUygulamasi;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		Queue<String> pideKuyrugu = new LinkedList<String>();
		
		Random random = new Random();
		
		pideKuyrugu.offer("Salih");
		pideKuyrugu.offer("Ali");
		pideKuyrugu.offer("Mehmet");
		pideKuyrugu.offer("Muhammed");
		pideKuyrugu.offer("Omar");
		pideKuyrugu.offer("Osman");
		pideKuyrugu.offer("Ebubekir");
		pideKuyrugu.offer("Ayşe");
		pideKuyrugu.offer("Hatice");
		pideKuyrugu.offer("Fatıma");
		
		System.out.println("Ramazan pidesi uygulamasına hoşgeldiniz...");
		
		int pideSayisi = 1 + random.nextInt(10);
		System.out.println("Pideler çıkmak üzere...");
		Thread.sleep(3000);
		System.out.println(pideSayisi + " pide çıktı");
		
		while(pideSayisi != 0) {
			
			System.out.println(pideKuyrugu.poll() + " pidesini aldı");
			Thread.sleep(1000);
			pideSayisi--;

			
			
		}
		
		
		System.out.println(" pide kalmadı ....");
	}

}
