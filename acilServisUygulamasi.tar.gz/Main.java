package acilServisUygulamasi;

import java.util.PriorityQueue;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<Hasta> acilServis = new PriorityQueue<Hasta>();
		
		acilServis.offer(new Hasta("Salih Bey","baş ağrısı"));
		acilServis.offer(new Hasta("Vahdet Bey","apandisit"));
		acilServis.offer(new Hasta("Selami Bey","öksürük"));
		acilServis.offer(new Hasta("Sema Hanım","yanık"));
		acilServis.offer(new Hasta("Hanife Hanım","apandisit"));
		acilServis.offer(new Hasta("Derya Hanım","baş ağrısı"));
		
		int i = 1;
		
		while(!acilServis.isEmpty()) {
			
			System.out.println(i + ". Sıradaki Hastamız : " + acilServis.poll());
			i++;
		}

		
		

	}

}
